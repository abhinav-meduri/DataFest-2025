2024-2025 DataFest Project on Real Estate Data - Aashish Cheruvu, Abhinav Meduri, Shravan Selvavel, Sharad Parulekar
